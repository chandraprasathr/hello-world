<?php

$dbservername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbdatabase = "school";

$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbdatabase);
